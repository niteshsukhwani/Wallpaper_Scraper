from .wallpaper_scraper_beautifulsoup import Wallpaper_Scraper

def Scraper(query, num):
    object = Wallpaper_Scraper()
    object.wallpaper_scraper(search_query = query, num_of_img = num)